-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: 51.254.119.45    Database: cognac
-- ------------------------------------------------------
-- Server version	5.7.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Affectation`
--

DROP TABLE IF EXISTS `Affectation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Affectation` (
  `id_Affectation` int(10) NOT NULL AUTO_INCREMENT,
  `id_Consultant` int(10) NOT NULL,
  `id_Projet` int(10) NOT NULL,
  `Pourcentage` int(10) NOT NULL,
  `DateDebut` date DEFAULT NULL,
  `DateFin` date DEFAULT NULL,
  PRIMARY KEY (`id_Affectation`),
  KEY `id_Consultant` (`id_Consultant`),
  KEY `id_Projet` (`id_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Affectation`
--

LOCK TABLES `Affectation` WRITE;
/*!40000 ALTER TABLE `Affectation` DISABLE KEYS */;
INSERT INTO `Affectation` VALUES (120,1,9,100,'2017-03-16','2017-03-25'),(121,1,3,100,'2017-03-16','2017-03-30'),(122,23,3,100,'2017-03-16','2017-03-29'),(123,41,3,100,'2017-03-16','2017-03-28'),(124,25,1,100,'2017-03-16','2017-03-30'),(125,27,1,100,'2017-03-16','2017-03-29'),(126,31,1,100,'2017-03-16','2017-03-29'),(127,31,2,100,'2017-03-16','2017-03-29'),(128,24,2,100,'2017-03-16','2017-03-20'),(129,25,3,80,'2017-03-16','2017-03-31'),(130,24,3,100,'2017-03-16','2017-03-22'),(131,23,12,100,'2017-03-16','2017-03-22');
/*!40000 ALTER TABLE `Affectation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Client` (
  `id_Client` int(10) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  PRIMARY KEY (`id_Client`),
  KEY `id_Client` (`id_Client`),
  KEY `Nom` (`Nom`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` VALUES (1,'Carlos'),(2,'Guillaume'),(6,'Toto'),(3,'Totoriko!');
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Consultant`
--

DROP TABLE IF EXISTS `Consultant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Consultant` (
  `id_consultant` int(10) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Prenom` varchar(50) DEFAULT NULL,
  `Email` varchar(75) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `TelPortable` varchar(20) DEFAULT NULL,
  `TelFixe` varchar(20) DEFAULT NULL,
  `DateNaissance` date DEFAULT NULL,
  `DateEntreeEntreprise` date DEFAULT NULL,
  `CoutJournalier` float DEFAULT NULL,
  `id_Statut` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_consultant`),
  KEY `id_consultant` (`id_consultant`),
  KEY `Prenom` (`Nom`),
  KEY `Nom` (`Prenom`),
  KEY `id_Statut` (`id_Statut`),
  KEY `FKConsultant235467` (`id_Statut`),
  CONSTRAINT `FKConsultant235467` FOREIGN KEY (`id_Statut`) REFERENCES `Statut` (`id_Statut`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Consultant`
--

LOCK TABLES `Consultant` WRITE;
/*!40000 ALTER TABLE `Consultant` DISABLE KEYS */;
INSERT INTO `Consultant` VALUES (23,'ALBERIDO','Lénaic','lenaic.alberido@altran.com',NULL,'06 88 87 08 13',NULL,'1993-08-04','2016-03-09',NULL,NULL),(24,'BROTONS ','Julien','julien.brotons@altran.com',NULL,'06 64 86 90 78',NULL,'1991-10-07','2016-01-01',NULL,NULL),(25,'CLAUDIN ','Christophe','christophe.claudin@altran.com',NULL,'06 81 01 02 68',NULL,'1983-09-01','2016-04-06',NULL,NULL),(26,'ESPY ','François Laurent','francoislaurent.espy@altran.com',NULL,'06 63 04 05 25',NULL,'1976-06-09','2016-08-05',NULL,NULL),(27,'FERRAO ','Florient','florient.ferrao@altran.com',NULL,'06 30 14 49 00',NULL,'1994-02-06','2016-10-09',NULL,NULL),(28,'GERAUD ','Fabien','fabien.geraud@altran.com',NULL,'06 44 92 31 47',NULL,'1993-05-08','2016-10-09',NULL,NULL),(29,'GUILLEVIC','Ronan','ronan.guillevic@altran.com',NULL,'06 08 41 51 43',NULL,'1982-08-05','2016-07-02',NULL,NULL),(30,'LEON ','Steve','steve.leon@altran.com',NULL,'06.45.09.88.90',NULL,'1985-07-08','2016-10-09',NULL,NULL),(32,'MOUCHARD','Yves','yves.mouchard@altran.com',NULL,'06.84.47.31.16',NULL,'1959-07-07','2006-01-11',NULL,NULL),(33,'RAMANGASEHENO ','Murielle','murielle.ramangaseheno@altran.com',NULL,'?',NULL,'1983-12-01','2012-03-08',NULL,NULL),(34,'RODRIGUES VEIGA ','Joao','joao.rodriguesveiga@altran.com',NULL,'07 83 84 91 12',NULL,'1985-06-05','2017-08-31',NULL,NULL),(35,'SOLTANI ','Marwah','marwah.soltani@altran.com',NULL,'06 50 50 58 32',NULL,'1990-07-31','2016-07-02',NULL,NULL),(36,'WINDELS','Gaëtan','gaetan.windelsalliancehightech.ext@altran.com',NULL,NULL,NULL,NULL,'2016-05-11',NULL,NULL),(37,'ABADIE ','Eric','eric.abadie@altran.com',NULL,'06 86 44 35 92',NULL,NULL,NULL,NULL,NULL),(38,'APPERT','Damien','damien.appert@altran.com',NULL,'06 84 92 25 59',NULL,'1987-09-20','2016-07-19',NULL,NULL),(39,'AGIER','Maéva','maeva.agier@altran.com',NULL,'06 15 27 85 20',NULL,'1997-03-03','2015-10-13',NULL,NULL),(40,'ABID ','Ahmed','ahmed.abid@altran.com',NULL,'06 76 07 77 64',NULL,NULL,'2015-09-30',NULL,NULL),(41,'ALBERIDO','Lénaic','lenaic.alberido@altran.com',NULL,'06 88 87 08 13',NULL,'1993-06-07','2016-11-02',NULL,NULL),(42,'ALLAINMAT','Jean-Joël','jean-joel.allainmat@altran.com',NULL,'06 49 08 38 51',NULL,'1982-05-25','2010-10-14',NULL,NULL),(43,'AVOT','Eglantine',NULL,NULL,'?',NULL,NULL,NULL,NULL,NULL),(44,'AZAM','Arthur','arthur.azam@altran.com',NULL,'06 82 87 52 58','05 34 61 01 53','1992-03-13','2015-04-22',NULL,NULL),(45,'BABOIN','Eric','eric.baboin@altran.com',NULL,'06 60 78 92 58 ',NULL,NULL,'2013-01-02',NULL,NULL),(46,'BALLIN ','Mandfred','mandfred.ballin@altran.com',NULL,'06 89 63 89 77',NULL,'1995-03-18','2016-11-09',NULL,NULL),(47,'BARRAIRON','Vincent','vincent.barrairon@altran.com',NULL,'06 76 74 31 54',NULL,'1989-04-28','2016-11-16',NULL,NULL),(48,'BATIFOL ','Anthony','anthony.batifol@altran.com',NULL,'06 66 01 99 81',NULL,'1987-05-26','2016-12-13',NULL,NULL),(49,'BENISON','Sahayamary','sahayamary.benison@altran.com',NULL,'07 83 66 39 99 ',NULL,'1990-08-15','2016-01-13',NULL,NULL),(50,'BENOITON ','Rémi','remi.benoiton@altran.com',NULL,'06 70 29 51 81',NULL,'1993-01-23','2016-11-16',NULL,NULL),(51,'BERGUA ','Laurie','laurie.bergua@altran.com',NULL,'06 08 58 95 05',NULL,'1993-08-27','2016-10-11',NULL,NULL),(52,'BERTOGAL','Bruno','bruno.bertogal@altran.com',NULL,'07 88 63 68 93',NULL,'1971-11-26','2015-05-07',NULL,NULL),(53,'BOUHLEL ','Amrou','amrou.bouhlel@altran.com',NULL,'07 81 35 54 61',NULL,'1990-03-02','2014-08-22',NULL,NULL),(54,'BRAMARDI ','Gauthier','gauthier.bramardi@altran.com',NULL,'07 83 23 08 26',NULL,'1989-10-14','2016-10-11',NULL,NULL),(55,'BRICHARD ','Quentin','quentin.brichard@altran.com',NULL,'07 61 87 92 50',NULL,'1990-08-28','2016-04-06',NULL,NULL),(56,'BRIGMANAS','Ludivine','ludivine.brigmanas@altran.com',NULL,'06 79 43 20 34',NULL,'1987-10-12','2016-11-09',NULL,NULL),(57,'BROTONS ','Julien','julien.brotons@altran.com',NULL,'06 64 86 90 78',NULL,'1991-09-09','2016-02-29',NULL,NULL),(58,'CASELLES','Adrien','adrien.caselles@altran.com',NULL,'06 99 04 98 91',NULL,'1992-07-09','2014-11-12',NULL,NULL),(59,'CASTANIE','Romain','romain.castanie@altran.com',NULL,'06 30 41 10 41',NULL,'1991-12-17','2016-09-22',NULL,NULL),(60,'CHARPENTREAU ','Charpentreau','guillaume.charpentreau@altran.com',NULL,'06 99 99 27 38',NULL,'1989-02-03','2016-10-25',NULL,NULL),(61,'CLAUDIN ','Christophe','christophe.claudin@altran.com',NULL,'06 81 01 02 68',NULL,'1983-03-08','2016-08-03',NULL,NULL),(62,'DAOUDI ','Yazid','yazid.daoudi@altran.com',NULL,'07 82 15 32 23',NULL,'1991-07-20','2016-11-02',NULL,NULL),(63,'DASSE ','Jean-François','jean-francois.dasse@altran.com',NULL,'06.70.66.25.31',NULL,'1963-07-13','2011-07-31',NULL,NULL),(64,'DAX ','Jennifer','jennifer.dax@altran.com',NULL,'06 22 87 47 98',NULL,'2012-02-08','1986-01-16',NULL,NULL),(65,'DELELIS ','Pascal','pascal.delelis@altran.com',NULL,'06 85 69 57 56',NULL,'1987-03-10','2014-05-28',NULL,NULL),(66,'DENIS ','Yoan','yoan.denis@altran.com',NULL,'06 99 28 58 99',NULL,'1987-08-14','2017-02-08',NULL,NULL),(67,'DESBIEYS ','Jean','jean.desbieys@altran.com',NULL,'06 42 25 34 31',NULL,NULL,NULL,NULL,NULL),(68,'EL AYADI ','Ayoub','ayoub.elayadi@altran.com',NULL,'07 81 77 71 99',NULL,'1989-10-13','2015-11-11',NULL,NULL),(69,'EL GAFA ','Naoufal','naoufal.elgafa@altran.com',NULL,'07 53 24 17 40',NULL,'1988-09-19','2015-11-11',NULL,NULL),(70,'ESCALARD','Alexis','alexis.escalard@altran.com',NULL,'06 45 27 25 91',NULL,'1990-03-23','2015-04-25',NULL,NULL),(71,'ESPY ','François Laurent','francoislaurent.espy@altran.com',NULL,'06 63 04 05 25',NULL,'1976-11-05','2016-07-07',NULL,NULL),(72,'FASSI FIHRI','Ismail','ismail.fassifihri@altran.com',NULL,'07 83 39 00 21',NULL,'1990-01-26','2015-03-01',NULL,NULL),(73,'FERRAO ','Florient','florient.ferrao@altran.com',NULL,'06 30 14 49 00',NULL,'1994-08-01','2016-11-09',NULL,NULL),(74,'GARENNE ','Maximilien','maximilien.garenne@altran.com',NULL,'06 60 86 83 13',NULL,'1991-01-29','2016-11-02',NULL,NULL),(75,'GENAILLE ','Camille','camille.genaille@altran.com',NULL,'06 87 13 75 67',NULL,'1990-10-27','2014-10-21',NULL,NULL),(76,'GERAUD ','Fabien','fabien.geraud@altran.com',NULL,'06 44 92 31 47',NULL,'1993-10-04','2016-11-09',NULL,NULL),(77,'GIRARD','Sébastien','sébastien.girard@altran.com',NULL,'?',NULL,'1974-08-13','2016-11-23',NULL,NULL),(78,'GROC ','William','william.groc@altran.com',NULL,'06 04 42 90 71',NULL,'1993-07-25','2016-09-15',NULL,NULL),(79,'GUILLEVIC','Ronan','ronan.guillevic@altran.com',NULL,'06 08 41 51 43',NULL,'1982-07-07','2016-04-06',NULL,NULL),(80,'JOUKOVSKY',' Naïm','naim.joukovsky@altran.com',NULL,'06 51 90 49 69',NULL,'1990-02-13','2016-10-31',NULL,NULL),(81,'LAUZE ','Marc','marc.lauze@altran.com',NULL,'06 15 77 90 48',NULL,'1995-03-01','2016-10-20',NULL,NULL),(82,'LE GOFF ','Camille','camille.legoff@altran.com',NULL,'07 50 28 99 43',NULL,'1991-12-21','2014-12-04',NULL,NULL),(83,'LECLERC ','Pierre','pierre.leclerc@altran.com',NULL,'06 10 19 93 89',NULL,'1994-01-12','2016-10-09',NULL,NULL),(84,'LEGARCON','Erwan','erwan.legarcon@altran.com',NULL,'06 11 37 45 92',NULL,'1974-08-09','2010-06-16',NULL,NULL),(85,'LEON ','Steve','steve.leon@altran.com',NULL,'06.45.09.88.90',NULL,'1985-10-06','2016-11-09',NULL,NULL),(86,'LOMBART ','Marie-Noëlle','marie-noelle.lombart@altran.com',NULL,'06 07 97 14 34',NULL,'1976-01-02','2007-09-19',NULL,NULL),(87,'LORILLOT ','Benoît','benoit.lorillot@altran.com',NULL,NULL,NULL,'1978-05-28','2016-12-06',NULL,NULL),(88,'MAISON ','Romain','romain.maison@altran.com',NULL,'06 08 83 78 34',NULL,'1984-07-22','2016-10-11',NULL,NULL),(89,'MARCHOIS ','Kevin','kevin.marchois@altran.com',NULL,'06 29 78 09 36',NULL,'1992-01-09','2016-11-16',NULL,NULL),(90,'MOREL ','Henri','henri.morel@altran.com',NULL,'06 51 29 15 06',NULL,'1975-01-23','2016-12-06',NULL,NULL),(92,'MOUCHARD','Yves','yves.mouchard@altran.com',NULL,'06.84.47.31.16',NULL,'1959-09-06','2006-12-31',NULL,NULL),(93,'NEIROTTI ','Catherine','catherine.neirotti@altran.com',NULL,'06 30 80 73 51',NULL,'1979-08-24','2015-12-22',NULL,NULL),(94,'NOTON HAUROT','Sébastien','sebastien.nautonhaurot@altran.com',NULL,'?',NULL,NULL,NULL,NULL,NULL),(95,'RAMANGASEHENO ','Murielle','murielle.ramangaseheno@altran.com',NULL,'?',NULL,'1983-03-11','2012-10-02',NULL,NULL),(96,'RENIER ','Guillaume','guillaume.renier@altran.com',NULL,'06 03 59 76 52',NULL,'1986-07-06','2016-04-13',NULL,NULL),(97,'RENN ','Benoit','benoit.renn@altran.com',NULL,'06 75 76 65 34',NULL,'1987-11-14','2011-11-16',NULL,NULL),(98,'RODRIGUES VEIGA ','Joao','joao.rodriguesveiga@altran.com',NULL,'07 83 84 91 12',NULL,'1985-07-05','2017-02-08',NULL,NULL),(99,'ROIG NEIRA ','Rodrigo','rodrigo.roigneira@altran.com',NULL,'06.63.16.25.73',NULL,'1982-04-27','2017-02-08',NULL,NULL),(100,'RUIZ','Alexandre','alexandre.ruiz@altran.com',NULL,'06 33 70 16 35',NULL,NULL,NULL,NULL,NULL),(101,'SAINT ROMAS','Guillaume','guillaume.saintromas@altran.com',NULL,'06 08 17 50 04',NULL,'1981-11-16','2015-05-26',NULL,NULL),(102,'SOLTANI ','Marwah','marwah.soltani@altran.com',NULL,'06 50 50 58 32',NULL,'1990-02-07','2016-04-06',NULL,NULL),(103,'TAMATORO','Kerekunuri','kerekunuri.tamatoroxlm.ext@altran.com',NULL,'06 61 17 10 88',NULL,NULL,'2016-11-16',NULL,NULL),(104,'TAMISIER ','Aurélien','aurelien.tamisier@altran.com',NULL,'?',NULL,'1989-10-16','2014-06-01',NULL,NULL),(105,'VABRE ','Romain','romain.vabre@altran.com',NULL,'06 72 48 99 97',NULL,'1991-11-30','2015-11-04',NULL,NULL),(106,'VITTORI ','Olivier','olivier.vittori@altran.com',NULL,'06 74 20 19 20',NULL,'1978-07-16','2016-09-21',NULL,NULL),(107,'VOLLANT ','Jérémy','jeremy.vollant@altran.com',NULL,'07 68 88 85 92',NULL,'1980-05-01','2017-12-23',NULL,NULL),(108,'WINDELS','Gaëtan','gaetan.windelsalliancehightech.ext@altran.com',NULL,NULL,NULL,NULL,'2017-01-04',NULL,NULL),(109,'WOUTERS',' David','david.wouters@altran.com',NULL,'06.82.05.76.58',NULL,'1971-08-22','2016-11-09',NULL,NULL);
/*!40000 ALTER TABLE `Consultant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Imputation`
--

DROP TABLE IF EXISTS `Imputation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Imputation` (
  `id_Imputation` int(10) NOT NULL AUTO_INCREMENT,
  `id_Consultant` int(10) NOT NULL,
  `id_Tache` int(10) NOT NULL,
  `Pourcentage` int(10) NOT NULL,
  `DateDebut` date DEFAULT NULL,
  `DateFin` date DEFAULT NULL,
  PRIMARY KEY (`id_Imputation`),
  KEY `id_Consultant` (`id_Consultant`),
  KEY `id_Tache` (`id_Tache`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Imputation`
--

LOCK TABLES `Imputation` WRITE;
/*!40000 ALTER TABLE `Imputation` DISABLE KEYS */;
INSERT INTO `Imputation` VALUES (1,1,20,40,NULL,NULL),(2,1,3,70,NULL,'2000-04-30'),(3,2,2,30,NULL,NULL),(10,2,42,90,'2009-10-04','2011-10-04'),(14,2,42,90,'2009-10-04','2011-10-04');
/*!40000 ALTER TABLE `Imputation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maitrise`
--

DROP TABLE IF EXISTS `Maitrise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Maitrise` (
  `id_Consultant` int(10) NOT NULL,
  `id_Techno` int(10) NOT NULL,
  `Niveau` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_Consultant`,`id_Techno`),
  KEY `id_Consultant` (`id_Consultant`),
  KEY `id_Techno` (`id_Techno`),
  KEY `FKMaitrise385011` (`id_Techno`),
  KEY `FKMaitrise308262` (`id_Consultant`),
  CONSTRAINT `FKMaitrise308262` FOREIGN KEY (`id_Consultant`) REFERENCES `Consultant` (`id_consultant`),
  CONSTRAINT `FKMaitrise385011` FOREIGN KEY (`id_Techno`) REFERENCES `Techno` (`id_Techno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maitrise`
--

LOCK TABLES `Maitrise` WRITE;
/*!40000 ALTER TABLE `Maitrise` DISABLE KEYS */;
/*!40000 ALTER TABLE `Maitrise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Projet`
--

DROP TABLE IF EXISTS `Projet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Projet` (
  `id_projet` int(10) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `DateDebut` date DEFAULT NULL,
  `DateFin` date DEFAULT NULL,
  `IdentifiantMinos` varchar(50) DEFAULT NULL,
  `IdentifiantHermes` varchar(50) DEFAULT NULL,
  `Adm` smallint(5) DEFAULT NULL,
  `id_Client` int(10) NOT NULL,
  PRIMARY KEY (`id_projet`),
  KEY `id_projet` (`id_projet`),
  KEY `id_Client` (`id_Client`),
  KEY `FKProjet832620` (`id_Client`),
  CONSTRAINT `FKProjet832620` FOREIGN KEY (`id_Client`) REFERENCES `Client` (`id_Client`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Projet`
--

LOCK TABLES `Projet` WRITE;
/*!40000 ALTER TABLE `Projet` DISABLE KEYS */;
INSERT INTO `Projet` VALUES (1,'Coco','2017-06-19','2018-05-13',NULL,NULL,50,1),(2,'Wines','2016-03-13','2016-11-08',NULL,NULL,20,1),(3,'Waters','2014-06-29','2016-03-29','5','5',NULL,2),(9,'Red','2010-10-03','2013-06-16',NULL,NULL,12,1),(12,'Beer','2009-10-04','2011-10-04',NULL,NULL,12,1);
/*!40000 ALTER TABLE `Projet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Statut`
--

DROP TABLE IF EXISTS `Statut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Statut` (
  `id_Statut` int(10) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(75) NOT NULL,
  PRIMARY KEY (`id_Statut`),
  KEY `id_Statut` (`id_Statut`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Statut`
--

LOCK TABLES `Statut` WRITE;
/*!40000 ALTER TABLE `Statut` DISABLE KEYS */;
INSERT INTO `Statut` VALUES (1,'Todo'),(2,'dadadfz'),(20,'cefpfkqd'),(21,'cefpfkqd,pddqm,qmzq'),(22,'cefpfkqd,pddqm,qmzq'),(23,'cefpfkqd,pddqm,qmzq'),(24,'cefpfkqd,pddqm,qmzq'),(25,'cefpfkqd,pddqm,qmzq'),(26,'cefpfkqd,pddqm,qmzq'),(27,'cefpfkqd,pddqm,qmzq'),(28,'cefpfkqd,pddqm,qmzq'),(29,'cefpfkqd,pddqm,qmzq');
/*!40000 ALTER TABLE `Statut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tache`
--

DROP TABLE IF EXISTS `Tache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tache` (
  `id_Tache` int(10) NOT NULL AUTO_INCREMENT,
  `DateDebut` date DEFAULT NULL,
  `dateFin` date DEFAULT NULL,
  `id_Projet` int(10) NOT NULL,
  `id_TacheParent` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_Tache`),
  KEY `id_Tache` (`id_Tache`),
  KEY `id_Projet` (`id_Projet`),
  KEY `FKTache786165` (`id_Projet`),
  KEY `FKTache638632` (`id_TacheParent`),
  CONSTRAINT `FKTache638632` FOREIGN KEY (`id_TacheParent`) REFERENCES `Tache` (`id_Tache`),
  CONSTRAINT `FKTache786165` FOREIGN KEY (`id_Projet`) REFERENCES `Projet` (`id_projet`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tache`
--

LOCK TABLES `Tache` WRITE;
/*!40000 ALTER TABLE `Tache` DISABLE KEYS */;
INSERT INTO `Tache` VALUES (1,'1000-06-10','2000-06-10',2,1),(3,'2018-06-10',NULL,2,1),(4,'2018-06-10',NULL,2,1),(6,'2018-06-10',NULL,2,1),(7,'2018-06-10',NULL,2,1),(8,'2018-06-10',NULL,2,1),(9,'2018-06-10',NULL,2,1),(11,'2018-06-10',NULL,2,1),(12,'2018-06-10',NULL,2,1),(13,'2018-06-10',NULL,2,1),(14,'2018-06-10',NULL,2,1),(15,'2018-06-10',NULL,2,1),(20,'2018-06-10',NULL,2,1),(190,'2000-06-10','2000-06-10',2,1),(200,'2018-06-10',NULL,2,1),(210,'2018-06-10',NULL,2,1),(220,'2018-06-10',NULL,2,1),(230,'2018-06-10',NULL,2,1),(232,'1000-06-10','2000-06-10',3,1);
/*!40000 ALTER TABLE `Tache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Techno`
--

DROP TABLE IF EXISTS `Techno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Techno` (
  `id_Techno` int(10) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  PRIMARY KEY (`id_Techno`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Techno`
--

LOCK TABLES `Techno` WRITE;
/*!40000 ALTER TABLE `Techno` DISABLE KEYS */;
INSERT INTO `Techno` VALUES (1,'Node'),(2,'Python'),(3,'Totoriko!'),(6,'Toto'),(7,'Express');
/*!40000 ALTER TABLE `Techno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Techno_Projet`
--

DROP TABLE IF EXISTS `Techno_Projet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Techno_Projet` (
  `id_Techno` int(10) NOT NULL,
  `id_Projet` int(10) NOT NULL,
  PRIMARY KEY (`id_Techno`,`id_Projet`),
  KEY `id_Techno` (`id_Techno`),
  KEY `id_Projet` (`id_Projet`),
  KEY `FKTechno_Pro265133` (`id_Techno`),
  KEY `FKTechno_Pro586764` (`id_Projet`),
  CONSTRAINT `FKTechno_Pro265133` FOREIGN KEY (`id_Techno`) REFERENCES `Techno` (`id_Techno`),
  CONSTRAINT `FKTechno_Pro586764` FOREIGN KEY (`id_Projet`) REFERENCES `Projet` (`id_projet`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Techno_Projet`
--

LOCK TABLES `Techno_Projet` WRITE;
/*!40000 ALTER TABLE `Techno_Projet` DISABLE KEYS */;
INSERT INTO `Techno_Projet` VALUES (1,1),(2,1),(2,2);
/*!40000 ALTER TABLE `Techno_Projet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-29 14:52:52
